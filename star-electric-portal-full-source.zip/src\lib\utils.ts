import type { BrandCategory, ItemStatus, PRStatus, LineItem, PRRecord } from '../types';

export function formatCurrencyPKR(amount: number): string {
  return new Intl.NumberFormat('en-PK', {
    style: 'currency',
    currency: 'PKR',
    maximumFractionDigits: 0
  }).format(amount).replace('PKR', 'Rs.');
}

export function formatDate(dateString: string): string {
  if (!dateString) return '';
  const d = new Date(dateString);
  if (isNaN(d.getTime())) return dateString;
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}

export function generateId(prefix: string = 'ID'): string {
  return `${prefix}-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
}

export function computeItemStatus(requested: number, fulfilled: number): ItemStatus {
  if (fulfilled <= 0) return 'Pending';
  if (fulfilled >= requested) return 'Completed';
  return 'Partially Fulfilled';
}

export function computePRStatus(items: LineItem[]): PRStatus {
  if (!items || items.length === 0) return 'Pending';
  const allCompleted = items.every(item => item.fulfilledQty >= item.requestedQty);
  if (allCompleted) return 'Fulfilled';
  const anyFulfilled = items.some(item => item.fulfilledQty > 0);
  if (anyFulfilled) return 'In-Progress';
  return 'Pending';
}

export function normalizeBrand(inputStr: string): BrandCategory {
  const str = inputStr.toLowerCase();
  if (str.includes('pakistan cable') || str.includes('pk cable')) return 'Pakistan Cables';
  if (str.includes('amer cable') || str.includes('amer')) return 'Amer Cables';
  if (str.includes('schneider') || str.includes('mcb') || str.includes('mccb')) return 'Schneider Electric';
  if (str.includes('terasaki')) return 'Terasaki';
  if (str.includes('philips') || str.includes('led') || str.includes('light') || str.includes('floodlight')) return 'Philips / Pak Lighting';
  if (str.includes('conduit') || str.includes('pvc') || str.includes('pipe') || str.includes('flex')) return 'Conduit & Accessories';
  if (str.includes('switch') || str.includes('socket') || str.includes('gang')) return 'Switches & Sockets';
  return 'General Electrical';
}

// Light theme brand badge styling
export function getBrandBadgeColor(brand: BrandCategory): string {
  switch (brand) {
    case 'Pakistan Cables':
      return 'bg-emerald-50 text-emerald-800 border-emerald-300';
    case 'Amer Cables':
      return 'bg-blue-50 text-blue-800 border-blue-300';
    case 'Schneider Electric':
      return 'bg-purple-50 text-purple-800 border-purple-300';
    case 'Terasaki':
      return 'bg-amber-50 text-amber-800 border-amber-300';
    case 'Philips / Pak Lighting':
      return 'bg-yellow-50 text-yellow-800 border-yellow-300';
    case 'Conduit & Accessories':
      return 'bg-slate-100 text-slate-800 border-slate-300';
    case 'Switches & Sockets':
      return 'bg-cyan-50 text-cyan-800 border-cyan-300';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-300';
  }
}

// Light theme status badge styling
export function getStatusBadgeColor(status: PRStatus | ItemStatus): string {
  switch (status) {
    case 'Fulfilled':
    case 'Completed':
      return 'bg-emerald-100 text-emerald-800 border-emerald-300 font-semibold';
    case 'In-Progress':
    case 'Partially Fulfilled':
      return 'bg-amber-100 text-amber-900 border-amber-300 font-semibold';
    case 'Pending':
    default:
      return 'bg-rose-100 text-rose-800 border-rose-300 font-semibold';
  }
}

export function calculatePRTotals(pr: PRRecord) {
  let totalRequestedVal = 0;
  let totalFulfilledVal = 0;
  let totalItemsCount = pr.items.length;
  let completedItemsCount = 0;

  pr.items.forEach(item => {
    const reqVal = item.requestedQty * item.unitPricePKR;
    const fulVal = item.fulfilledQty * item.unitPricePKR;
    totalRequestedVal += reqVal;
    totalFulfilledVal += fulVal;
    if (item.fulfilledQty >= item.requestedQty) {
      completedItemsCount++;
    }
  });

  const percentage = totalItemsCount > 0 
    ? Math.round((completedItemsCount / totalItemsCount) * 100)
    : 0;

  return {
    totalRequestedVal,
    totalFulfilledVal,
    totalItemsCount,
    completedItemsCount,
    percentage
  };
}
