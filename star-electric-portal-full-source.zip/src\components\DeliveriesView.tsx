import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Truck, 
  Building2, 
  Calendar, 
  Plus,
  ArrowRight,
  Trash2
} from 'lucide-react';

export const DeliveriesView: React.FC = () => {
  const { dcs, setIsDCUploadOpen, setSelectedPR, setIsPRDetailOpen, prs, deleteDC } = useApp();

  return (
    <div className="space-y-6 w-full text-slate-900">
      
      {/* Header Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Truck className="w-5 h-5 text-emerald-600" />
            Delivery Challans & Invoices Log
          </h2>
          <p className="text-xs text-slate-500 font-medium mt-0.5">
            Unified record matching Delivery Challan Number strictly with Invoice Number
          </p>
        </div>

        <button
          onClick={() => setIsDCUploadOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all self-start md:self-auto"
        >
          <Plus className="w-4 h-4" /> Issue DC & Invoice
        </button>
      </div>

      {/* DCs List Grid */}
      <div className="space-y-3">
        {dcs.length === 0 ? (
          <div className="p-8 text-center bg-white border border-slate-200 rounded-2xl text-slate-500 text-xs font-semibold shadow-xs">
            No Delivery Challans have been generated yet.
          </div>
        ) : (
          dcs.map(dc => {
            const linkedPR = prs.find(p => p.id === dc.prId || p.prNumber === dc.prNumber);

            return (
              <div
                key={dc.id}
                className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 hover:border-slate-300 transition-all shadow-xs"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-800 font-extrabold font-mono text-xs">
                      DC
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-extrabold text-slate-900 text-sm">{dc.dcNumber}</span>
                        <span className="text-slate-400 font-bold">=</span>
                        <span className="font-mono font-extrabold text-emerald-700 text-sm">{dc.invoiceNumber}</span>
                      </div>
                      <p className="text-xs text-slate-600 flex items-center gap-1.5 font-semibold mt-0.5">
                        <Building2 className="w-3.5 h-3.5 text-blue-600" /> {dc.siteName}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-600 flex items-center gap-1 font-mono font-semibold">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" /> {dc.date}
                    </span>

                    {linkedPR && (
                      <button
                        onClick={() => {
                          setSelectedPR(linkedPR);
                          setIsPRDetailOpen(true);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-amber-100 text-slate-800 hover:text-amber-900 text-xs font-bold border border-slate-300 flex items-center gap-1 transition-colors shadow-2xs"
                      >
                        PR #{dc.prNumber} <ArrowRight className="w-3 h-3" />
                      </button>
                    )}

                    {/* Delete DC Button */}
                    <button
                      onClick={() => {
                        if (confirm(`Delete Delivery Challan ${dc.dcNumber}? This will restore shipped quantities back to PR.`)) {
                          deleteDC(dc.id);
                        }
                      }}
                      className="p-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 transition-colors"
                      title="Delete Delivery Challan Record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Shipped Items */}
                <div className="space-y-2">
                  <h4 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Dispatched Items
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {dc.itemsShipped.map((item, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                        <div>
                          <p className="font-bold text-slate-900">{item.itemName}</p>
                          <span className="text-[10px] text-slate-500 font-semibold">{item.brand}</span>
                        </div>
                        <span className="font-mono font-extrabold text-emerald-800 px-2 py-0.5 rounded-full bg-emerald-100 border border-emerald-300">
                          {item.quantity} {item.unit}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {(dc.transportType || dc.addaName || dc.biltyNumber || dc.driverName || dc.vehicleNumber || dc.remarks) && (
                  <div className="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-wrap items-center gap-3 font-semibold">
                    {dc.transportType === 'Adda / Goods Transport' || dc.addaName ? (
                      <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 font-extrabold border border-amber-300 flex items-center gap-1.5">
                        🚚 Adda: {dc.addaName || 'Goods Adda'} | Bilty #{dc.biltyNumber || 'N/A'} | Freight: {dc.isFreightFree || dc.freightCharges === 0 ? 'FREE / مفت' : `PKR ${dc.freightCharges}`}
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-lg bg-blue-100 text-blue-900 font-extrabold border border-blue-300 flex items-center gap-1.5">
                        🚗 Driver: {dc.driverName || 'N/A'} | Vehicle: {dc.vehicleNumber || 'N/A'}
                      </span>
                    )}

                    {dc.remarks && (
                      <span className="text-slate-600 italic">"{dc.remarks}"</span>
                    )}
                  </div>
                )}

              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
