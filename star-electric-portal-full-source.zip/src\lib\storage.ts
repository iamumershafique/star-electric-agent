import type { PRRecord, DCRecord, FulfillmentLog } from '../types';
import { computeItemStatus, computePRStatus } from './utils';

const STORAGE_KEY_PRS = 'STAR_ELECTRIC_PRS_V2';
const STORAGE_KEY_DCS = 'STAR_ELECTRIC_DCS_V2';
const STORAGE_KEY_API_KEY = 'STAR_ELECTRIC_GEMINI_KEY';

export const INITIAL_SITES: any[] = [];

export const INITIAL_PRS: PRRecord[] = [
  {
    id: 'pr-seed-613',
    prNumber: 'PR-JAD-2026-613',
    date: '2026-09-10',
    siteName: 'Jadeed Farm - Khanewal Site B (Broiler Unit)',
    status: 'In-Progress',
    createdTimestamp: Date.now() - 6 * 86400000,
    contactPerson: 'Engr. Tariq Mahmood (Project Manager)',
    notes: 'Urgent expansion requirement for Shed #4 & Shed #5 main power distribution.',
    items: [
      {
        id: 'item-613-1',
        name: '95mm 4-Core Armoured XLPE Copper Cable',
        brand: 'Pakistan Cables',
        requestedQty: 400,
        fulfilledQty: 250,
        unit: 'Meters',
        unitPricePKR: 4850,
        status: 'Partially Fulfilled',
        specifications: '600/1000V Standard XLPE/PVC/SWA/PVC'
      },
      {
        id: 'item-613-2',
        name: '250A 3-Pole MCCB Breaker (Adjustable)',
        brand: 'Schneider Electric',
        requestedQty: 6,
        fulfilledQty: 4,
        unit: 'Pcs',
        unitPricePKR: 45000,
        status: 'Partially Fulfilled',
        specifications: 'NSX250F 36kA Frame'
      },
      {
        id: 'item-613-3',
        name: '150W IP66 LED Floodlight (6500K)',
        brand: 'Philips / Pak Lighting',
        requestedQty: 40,
        fulfilledQty: 40,
        unit: 'Pcs',
        unitPricePKR: 8800,
        status: 'Completed',
        specifications: 'Heavy Die-cast Aluminium Housing'
      }
    ],
    fulfillmentLogs: [
      {
        id: 'flog-613-1',
        dcNumber: 'DC-613',
        invoiceNumber: 'INV-613',
        prNumber: 'PR-JAD-2026-613',
        itemId: 'item-613-1',
        itemName: '95mm 4-Core Armoured XLPE Copper Cable',
        quantityShipped: 250,
        date: '2026-09-12',
        deliveredBy: 'Shahid Electrical Transport (Vehicle # LES-4812)',
        notes: 'First dispatch of cable reel #1.'
      },
      {
        id: 'flog-613-2',
        dcNumber: 'DC-613',
        invoiceNumber: 'INV-613',
        prNumber: 'PR-JAD-2026-613',
        itemId: 'item-613-2',
        itemName: '250A 3-Pole MCCB Breaker (Adjustable)',
        quantityShipped: 4,
        date: '2026-09-12',
        deliveredBy: 'Shahid Electrical Transport (Vehicle # LES-4812)',
        notes: 'Delivered along with DC #613.'
      },
      {
        id: 'flog-613-3',
        dcNumber: 'DC-613',
        invoiceNumber: 'INV-613',
        prNumber: 'PR-JAD-2026-613',
        itemId: 'item-613-3',
        itemName: '150W IP66 LED Floodlight (6500K)',
        quantityShipped: 40,
        date: '2026-09-12',
        deliveredBy: 'Shahid Electrical Transport (Vehicle # LES-4812)',
        notes: 'Complete lot delivered.'
      }
    ]
  },
  {
    id: 'pr-seed-614',
    prNumber: 'PR-JAD-2026-614',
    date: '2026-09-14',
    siteName: 'Jadeed Hatchery - Chakwal Main Complex',
    status: 'Pending',
    createdTimestamp: Date.now() - 2 * 86400000,
    contactPerson: 'Malik Zafar (Electrical Superintendent)',
    notes: 'Incubator hall wiring revamp.',
    items: [
      {
        id: 'item-614-1',
        name: '50mm 4-Core Flexible Cu Power Cable',
        brand: 'Amer Cables',
        requestedQty: 300,
        fulfilledQty: 0,
        unit: 'Meters',
        unitPricePKR: 2450,
        status: 'Pending',
        specifications: 'Heavy Duty Flexible Copper PVC'
      },
      {
        id: 'item-614-2',
        name: '100A 3-Pole Air Circuit Breaker',
        brand: 'Terasaki',
        requestedQty: 4,
        fulfilledQty: 0,
        unit: 'Pcs',
        unitPricePKR: 32000,
        status: 'Pending',
        specifications: 'Industrial Grade DB Switchboard'
      },
      {
        id: 'item-614-3',
        name: '2 Inch PVC Heavy Electrical Conduit Pipe',
        brand: 'Conduit & Accessories',
        requestedQty: 100,
        fulfilledQty: 0,
        unit: 'Lengths',
        unitPricePKR: 920,
        status: 'Pending',
        specifications: '10ft length heavy gauge PVC'
      }
    ],
    fulfillmentLogs: []
  },
  {
    id: 'pr-seed-601',
    prNumber: 'PR-JAD-2026-601',
    date: '2026-09-02',
    siteName: 'Jadeed Layer Farm - Sahiwal South',
    status: 'Fulfilled',
    createdTimestamp: Date.now() - 14 * 86400000,
    contactPerson: 'Asif Raza (Site Supervisor)',
    notes: 'Generator connection synchronization panel supplies.',
    items: [
      {
        id: 'item-601-1',
        name: '70mm 4-Core Armoured Copper Cable',
        brand: 'Pakistan Cables',
        requestedQty: 200,
        fulfilledQty: 200,
        unit: 'Meters',
        unitPricePKR: 3600,
        status: 'Completed',
        specifications: 'Pakistan Cables certified reel'
      },
      {
        id: 'item-601-2',
        name: '10-Gang Waterproof Industrial Switch Board',
        brand: 'Switches & Sockets',
        requestedQty: 15,
        fulfilledQty: 15,
        unit: 'Sets',
        unitPricePKR: 4200,
        status: 'Completed',
        specifications: 'IP65 Rated Box'
      }
    ],
    fulfillmentLogs: [
      {
        id: 'flog-601-1',
        dcNumber: 'DC-601',
        invoiceNumber: 'INV-601',
        prNumber: 'PR-JAD-2026-601',
        itemId: 'item-601-1',
        itemName: '70mm 4-Core Armoured Copper Cable',
        quantityShipped: 200,
        date: '2026-09-05',
        deliveredBy: 'Star Electric Express Delivery (Driver: Imtiaz)'
      },
      {
        id: 'flog-601-2',
        dcNumber: 'DC-601',
        invoiceNumber: 'INV-601',
        prNumber: 'PR-JAD-2026-601',
        itemId: 'item-601-2',
        itemName: '10-Gang Waterproof Industrial Switch Board',
        quantityShipped: 15,
        date: '2026-09-05',
        deliveredBy: 'Star Electric Express Delivery (Driver: Imtiaz)'
      }
    ]
  }
];

export const INITIAL_DCS: DCRecord[] = [
  {
    id: 'dc-seed-613',
    dcNumber: 'DC-613',
    invoiceNumber: 'INV-613',
    prNumber: 'PR-JAD-2026-613',
    prId: 'pr-seed-613',
    date: '2026-09-12',
    siteName: 'Jadeed Farm - Khanewal Site B (Broiler Unit)',
    itemsShipped: [
      { itemId: 'item-613-1', itemName: '95mm 4-Core Armoured XLPE Copper Cable', brand: 'Pakistan Cables', quantity: 250, unit: 'Meters' },
      { itemId: 'item-613-2', itemName: '250A 3-Pole MCCB Breaker (Adjustable)', brand: 'Schneider Electric', quantity: 4, unit: 'Pcs' },
      { itemId: 'item-613-3', itemName: '150W IP66 LED Floodlight (6500K)', brand: 'Philips / Pak Lighting', quantity: 40, unit: 'Pcs' }
    ],
    createdTimestamp: Date.now() - 4 * 86400000,
    driverName: 'Muhammad Rasheed',
    vehicleNumber: 'LES-4812 (Bedford Truck)',
    remarks: 'Partial dispatch of 95mm cable (250m shipped, 150m balance remaining).'
  },
  {
    id: 'dc-seed-601',
    dcNumber: 'DC-601',
    invoiceNumber: 'INV-601',
    prNumber: 'PR-JAD-2026-601',
    prId: 'pr-seed-601',
    date: '2026-09-05',
    siteName: 'Jadeed Layer Farm - Sahiwal South',
    itemsShipped: [
      { itemId: 'item-601-1', itemName: '70mm 4-Core Armoured Copper Cable', brand: 'Pakistan Cables', quantity: 200, unit: 'Meters' },
      { itemId: 'item-601-2', itemName: '10-Gang Waterproof Industrial Switch Board', brand: 'Switches & Sockets', quantity: 15, unit: 'Sets' }
    ],
    createdTimestamp: Date.now() - 11 * 86400000,
    driverName: 'Imtiaz Ahmed',
    vehicleNumber: 'RIP-3910 (Bolan Pickup)',
    remarks: 'Full fulfillment of PR-JAD-2026-601.'
  }
];

export function getPRs(): PRRecord[] {
  const data = localStorage.getItem(STORAGE_KEY_PRS);
  if (data === null) {
    return [];
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to parse PRs from storage', e);
    return [];
  }
}

export function saveAllPRs(prs: PRRecord[]): void {
  localStorage.setItem(STORAGE_KEY_PRS, JSON.stringify(prs));
}

export function getDCs(): DCRecord[] {
  const data = localStorage.getItem(STORAGE_KEY_DCS);
  if (data === null) {
    return [];
  }
  try {
    return JSON.parse(data);
  } catch (e) {
    console.error('Failed to parse DCs from storage', e);
    return [];
  }
}

export function saveAllDCs(dcs: DCRecord[]): void {
  localStorage.setItem(STORAGE_KEY_DCS, JSON.stringify(dcs));
}

export function checkDuplicatePR(prNumber: string, idToIgnore?: string): { isDuplicate: boolean; existingPR?: PRRecord } {
  const prs = getPRs();
  const normalizedSearch = prNumber.trim().toLowerCase();
  
  const match = prs.find(pr => 
    pr.id !== idToIgnore && 
    (pr.prNumber.trim().toLowerCase() === normalizedSearch ||
     pr.prNumber.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() === normalizedSearch.replace(/[^a-zA-Z0-9]/g, ''))
  );

  return {
    isDuplicate: !!match,
    existingPR: match
  };
}

export function savePR(pr: PRRecord): PRRecord[] {
  const prs = getPRs();
  const updatedItems = pr.items.map(item => ({
    ...item,
    status: computeItemStatus(item.requestedQty, item.fulfilledQty)
  }));
  
  const updatedPR: PRRecord = {
    ...pr,
    items: updatedItems,
    status: computePRStatus(updatedItems)
  };

  const existingIndex = prs.findIndex(p => p.id === pr.id);
  let updatedList: PRRecord[];

  if (existingIndex >= 0) {
    updatedList = [...prs];
    updatedList[existingIndex] = updatedPR;
  } else {
    updatedList = [updatedPR, ...prs];
  }

  saveAllPRs(updatedList);
  return updatedList;
}

export function deletePR(prId: string): PRRecord[] {
  const prs = getPRs().filter(p => p.id !== prId);
  saveAllPRs(prs);
  return prs;
}

export function deleteDC(dcId: string): { updatedPRs: PRRecord[]; updatedDCs: DCRecord[] } {
  const dcs = getDCs();
  const prs = getPRs();

  const targetDC = dcs.find(d => d.id === dcId);
  if (!targetDC) return { updatedPRs: prs, updatedDCs: dcs };

  const updatedDCs = dcs.filter(d => d.id !== dcId);

  // Recalculate PR fulfillment
  const targetPRIndex = prs.findIndex(p => p.id === targetDC.prId || p.prNumber === targetDC.prNumber);
  let updatedPRs = prs;

  if (targetPRIndex >= 0) {
    const pr = prs[targetPRIndex];
    // Remove fulfillment logs matching dcNumber
    const remainingLogs = (pr.fulfillmentLogs || []).filter(l => l.dcNumber !== targetDC.dcNumber);

    // Recompute fulfilled quantities from remaining logs
    const itemFulfilledTotals: Record<string, number> = {};
    remainingLogs.forEach(log => {
      itemFulfilledTotals[log.itemId] = (itemFulfilledTotals[log.itemId] || 0) + log.quantityShipped;
    });

    const updatedItems = pr.items.map(item => {
      const newFulfilled = itemFulfilledTotals[item.id] || 0;
      return {
        ...item,
        fulfilledQty: newFulfilled,
        status: computeItemStatus(item.requestedQty, newFulfilled)
      };
    });

    const updatedPR: PRRecord = {
      ...pr,
      items: updatedItems,
      fulfillmentLogs: remainingLogs,
      status: computePRStatus(updatedItems)
    };

    updatedPRs = [...prs];
    updatedPRs[targetPRIndex] = updatedPR;
    saveAllPRs(updatedPRs);
  }

  saveAllDCs(updatedDCs);
  return { updatedPRs, updatedDCs };
}

export function saveDCAndFulfillPR(
  dcData: Omit<DCRecord, 'id' | 'createdTimestamp'>,
  fulfillmentMap: Record<string, number>
): { updatedPRs: PRRecord[]; updatedDCs: DCRecord[]; newDC: DCRecord } {
  const prs = getPRs();
  const dcs = getDCs();

  const targetPRIndex = prs.findIndex(p => p.id === dcData.prId || p.prNumber === dcData.prNumber);
  if (targetPRIndex === -1) {
    throw new Error(`Target Purchase Requisition ${dcData.prNumber} not found.`);
  }

  const targetPR = prs[targetPRIndex];
  const syncedDCNumber = dcData.dcNumber.trim();
  const syncedInvoiceNumber = dcData.dcNumber.trim();

  const itemsShippedList: DCRecord['itemsShipped'] = [];
  const newFulfillmentLogs: FulfillmentLog[] = [];

  const updatedItems = targetPR.items.map(item => {
    const shippedQty = fulfillmentMap[item.id] || 0;
    if (shippedQty > 0) {
      const newFulfilledTotal = item.fulfilledQty + shippedQty;
      
      itemsShippedList.push({
        itemId: item.id,
        itemName: item.name,
        brand: item.brand,
        quantity: shippedQty,
        unit: item.unit
      });

      const logEntry: FulfillmentLog = {
        id: `flog-${Math.random().toString(36).substring(2, 9)}`,
        dcNumber: syncedDCNumber,
        invoiceNumber: syncedInvoiceNumber,
        prNumber: targetPR.prNumber,
        itemId: item.id,
        itemName: item.name,
        quantityShipped: shippedQty,
        date: dcData.date,
        transportType: dcData.transportType,
        addaName: dcData.addaName,
        biltyNumber: dcData.biltyNumber,
        freightCharges: dcData.freightCharges,
        isFreightFree: dcData.isFreightFree,
        driverName: dcData.driverName,
        vehicleNo: dcData.vehicleNumber,
        notes: dcData.remarks
      };

      newFulfillmentLogs.push(logEntry);

      return {
        ...item,
        fulfilledQty: newFulfilledTotal,
        status: computeItemStatus(item.requestedQty, newFulfilledTotal)
      };
    }
    return item;
  });

  const updatedPR: PRRecord = {
    ...targetPR,
    items: updatedItems,
    status: computePRStatus(updatedItems),
    fulfillmentLogs: [...(targetPR.fulfillmentLogs || []), ...newFulfillmentLogs]
  };

  const newDC: DCRecord = {
    ...dcData,
    id: `dc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    dcNumber: syncedDCNumber,
    invoiceNumber: syncedInvoiceNumber,
    itemsShipped: itemsShippedList,
    createdTimestamp: Date.now()
  };

  const updatedPRList = [...prs];
  updatedPRList[targetPRIndex] = updatedPR;
  const updatedDCList = [newDC, ...dcs];

  saveAllPRs(updatedPRList);
  saveAllDCs(updatedDCList);

  return { updatedPRs: updatedPRList, updatedDCs: updatedDCList, newDC };
}

export function getGeminiApiKey(): string {
  return localStorage.getItem(STORAGE_KEY_API_KEY) || '';
}

export function saveGeminiApiKey(key: string): void {
  localStorage.setItem(STORAGE_KEY_API_KEY, key);
}

// Security protected Master Reset (Wipes database to 100% empty slate)
export function masterResetWithPassword(password: string): { success: boolean; prs: PRRecord[]; dcs: DCRecord[]; error?: string } {
  if (password.trim() !== '2214') {
    return { success: false, prs: getPRs(), dcs: getDCs(), error: 'Incorrect Security Password (2214 required).' };
  }
  localStorage.setItem(STORAGE_KEY_PRS, JSON.stringify([]));
  localStorage.setItem(STORAGE_KEY_DCS, JSON.stringify([]));
  return { success: true, prs: [], dcs: [] };
}

export function resetToSeedData(): { prs: PRRecord[]; dcs: DCRecord[] } {
  localStorage.setItem(STORAGE_KEY_PRS, JSON.stringify(INITIAL_PRS));
  localStorage.setItem(STORAGE_KEY_DCS, JSON.stringify(INITIAL_DCS));
  return { prs: INITIAL_PRS, dcs: INITIAL_DCS };
}
