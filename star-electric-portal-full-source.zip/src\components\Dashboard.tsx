import React from 'react';
import { useApp } from '../context/AppContext';
import { formatCurrencyPKR, getStatusBadgeColor } from '../lib/utils';
import { 
  FileCheck2, 
  Clock, 
  CheckCircle2, 
  Building, 
  TrendingUp, 
  Zap, 
  ArrowRight,
  ShieldCheck,
  FileUp,
  Sparkles,
  Truck
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { 
    prs, 
    dcs,
    sites, 
    setActiveTab, 
    setIsPRUploadOpen, 
    setIsDCUploadOpen,
    setSelectedPR,
    setIsPRDetailOpen,
    setSearchQuery
  } = useApp();

  const totalPRs = prs.length;
  const fulfilledPRs = prs.filter(p => p.status === 'Fulfilled').length;
  const inProgressPRs = prs.filter(p => p.status === 'In-Progress').length;
  const pendingPRs = prs.filter(p => p.status === 'Pending').length;

  let totalDemandedValue = 0;
  let totalFulfilledValue = 0;
  let totalLineItems = 0;
  let fulfilledLineItems = 0;

  prs.forEach(pr => {
    pr.items.forEach(item => {
      totalLineItems++;
      totalDemandedValue += item.requestedQty * item.unitPricePKR;
      totalFulfilledValue += item.fulfilledQty * item.unitPricePKR;
      if (item.fulfilledQty >= item.requestedQty) {
        fulfilledLineItems++;
      }
    });
  });

  const fulfillmentPercentage = totalLineItems > 0 
    ? Math.round((fulfilledLineItems / totalLineItems) * 100) 
    : 0;



  return (
    <div className="w-full flex flex-col gap-3 lg:h-[calc(100vh-125px)] lg:max-h-[calc(100vh-125px)] overflow-y-auto lg:overflow-hidden">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400 rounded-xl p-3.5 shadow-sm text-slate-950 shrink-0 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded bg-white text-slate-900 font-extrabold text-[10px] uppercase tracking-wider shadow-2xs">
                Retail & Wholesale Electrical Supplier
              </span>
              <span className="text-slate-950 text-xs font-bold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-slate-950" /> Authorized Jadeed Vendor
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Jadeed Group Supply Chain Portal
            </h2>
            <p className="text-slate-900 text-xs mt-0.5 font-semibold">
              Star Electric Enterprises (Saddar, Rawalpindi) • Real-time Demand & Delivery Fulfillment Dashboard
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsPRUploadOpen(true)}
              className="px-4 py-2 rounded-lg bg-amber-700 hover:bg-amber-800 text-white font-extrabold text-xs shadow-xs flex items-center gap-1.5 transition-all active:scale-95"
            >
              <FileUp className="w-4 h-4" />
              Scan Demand PR
              <Sparkles className="w-3 h-3" />
            </button>
            <button
              onClick={() => setIsDCUploadOpen(true)}
              className="px-3.5 py-2 rounded-lg bg-white hover:bg-slate-100 text-slate-950 border border-slate-300 text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-2xs"
            >
              <Truck className="w-4 h-4 text-emerald-600" />
              Record DC / Invoice
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards (4 columns) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 shrink-0">
        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">Total Requisitions</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">{totalPRs}</span>
            <span className="text-xs text-slate-500 font-semibold">PR Orders</span>
          </div>
          <div className="text-[11px] text-slate-600 flex items-center gap-1 pt-1 border-t border-slate-100">
            <span className="text-blue-700 font-bold">{formatCurrencyPKR(totalDemandedValue)}</span>
            <span>demanded</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">Active Pending</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-amber-600">{inProgressPRs + pendingPRs}</span>
            <span className="text-xs text-slate-500 font-semibold">Active PRs</span>
          </div>
          <div className="text-[11px] text-slate-600 flex items-center gap-1.5 pt-1 border-t border-slate-100">
            <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 font-bold text-[10px] border border-amber-300">
              {inProgressPRs} In-Progress
            </span>
            <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-900 font-bold text-[10px] border border-rose-300">
              {pendingPRs} Pending
            </span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">Fulfilled Orders</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-emerald-600">{fulfilledPRs}</span>
            <span className="text-xs text-slate-500 font-semibold">Completed</span>
          </div>
          <div className="text-[11px] text-slate-600 flex items-center gap-1 pt-1 border-t border-slate-100">
            <span className="text-emerald-700 font-bold">{formatCurrencyPKR(totalFulfilledValue)}</span>
            <span>shipped</span>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider">Fulfillment Rate</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 border border-purple-200 flex items-center justify-center text-purple-600">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-extrabold text-slate-900">{fulfillmentPercentage}%</span>
            <span className="text-[10px] text-slate-500 font-semibold">
              ({fulfilledLineItems}/{totalLineItems} Items)
            </span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200">
            <div 
              className="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${fulfillmentPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Content Area: Fits in remaining desktop height with scrollable panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 flex-1 min-h-0">
        
        {/* Left Column (2 Cols): Recent Requisitions */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-3.5 shadow-xs flex flex-col min-h-0">
          <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-100 shrink-0">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-500" />
                Recent Requisitions (Jadeed Group)
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">Incoming demand sheets & status</p>
            </div>

            <button
              onClick={() => setActiveTab('ledger')}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1"
            >
              Master Ledger <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2 overflow-y-auto flex-1 min-h-0 pr-1">
            {prs.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                <p className="text-xs font-bold text-slate-700">No requisitions recorded yet</p>
                <p className="text-[11px] text-slate-500">Click "Scan Demand PR" to upload a demand sheet.</p>
              </div>
            ) : (
              prs.slice(0, 6).map(pr => {
                const completedItems = pr.items.filter(i => i.fulfilledQty >= i.requestedQty).length;
                const progressPct = pr.items.length > 0 ? Math.round((completedItems / pr.items.length) * 100) : 0;

                return (
                  <div
                    key={pr.id}
                    onClick={() => {
                      setSelectedPR(pr);
                      setIsPRDetailOpen(true);
                    }}
                    className="p-3 rounded-lg bg-slate-50 hover:bg-amber-50/60 border border-slate-200 hover:border-amber-300 transition-all cursor-pointer group flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-slate-900 group-hover:text-amber-800 transition-colors">
                          {pr.prNumber}
                        </span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border ${getStatusBadgeColor(pr.status)}`}>
                          {pr.status}
                        </span>
                      </div>
                      <p className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <Building className="w-3.5 h-3.5 text-blue-600" />
                        {pr.siteName}
                      </p>
                      <span className="text-[10px] text-slate-500 font-medium">
                        Date: {pr.date} • {pr.items.length} Line Items
                      </span>
                    </div>

                    <div className="flex items-center gap-3 sm:flex-col sm:items-end shrink-0">
                      <div className="text-right">
                        <span className="text-[11px] font-bold text-slate-800">
                          {completedItems}/{pr.items.length} Fulfilled
                        </span>
                        <div className="w-28 bg-slate-200 h-1.5 rounded-full mt-1 overflow-hidden border border-slate-300">
                          <div
                            className="bg-emerald-500 h-full rounded-full transition-all"
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                      </div>

                      <button className="px-2.5 py-1 rounded bg-white group-hover:bg-amber-500 text-slate-900 group-hover:text-slate-950 text-xs font-extrabold border border-slate-300 transition-colors shadow-2xs">
                        Inspect
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column (1 Col): Split vertically between Major Brands & Farm Locations */}
        <div className="flex flex-col gap-3 min-h-0">
          
          {/* Top Card: Recent Delivery Challans & Invoices (DCs) */}
          <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-xs flex flex-col flex-1 min-h-0">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 shrink-0">
              <h3 className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                <Truck className="w-3.5 h-3.5 text-emerald-600" />
                Recent Delivery Challans (DCs)
              </h3>
              <button
                onClick={() => setActiveTab('deliveries')}
                className="text-[11px] font-bold text-amber-700 hover:underline"
              >
                All DCs ({dcs.length})
              </button>
            </div>

            <div className="space-y-2 overflow-y-auto flex-1 min-h-0 pt-2 pr-1">
              {dcs.length === 0 ? (
                <div className="text-center py-4 text-[11px] text-slate-500 font-medium">
                  No Delivery Challans generated yet. Click "Record DC" to create one.
                </div>
              ) : (
                dcs.slice(0, 5).map(dc => (
                  <div 
                    key={dc.id} 
                    onClick={() => setActiveTab('deliveries')}
                    className="p-2 rounded-lg bg-slate-50 hover:bg-emerald-50/60 border border-slate-200 hover:border-emerald-300 transition-all cursor-pointer space-y-1 shadow-2xs"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono font-extrabold text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded border border-emerald-300 text-[11px]">
                        {dc.dcNumber}
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">{dc.date}</span>
                    </div>
                    <p className="text-[11px] font-bold text-slate-900 truncate">
                      {dc.siteName}
                    </p>
                    <div className="flex items-center justify-between text-[10px] text-slate-600 font-semibold">
                      <span>{dc.itemsShipped.length} Line Item(s)</span>
                      <span className="text-blue-800 font-extrabold font-mono">PR #{dc.prNumber}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Bottom Card: Jadeed Group Farm Locations */}
          <div className="bg-white border border-slate-200 rounded-xl p-3 shadow-xs flex flex-col flex-1 min-h-0">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 shrink-0">
              <h3 className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-blue-600" />
                Jadeed Group Farm Locations
              </h3>
              <span className="text-[10px] font-bold text-slate-500">{sites.length} Active</span>
            </div>

            <div className="overflow-y-auto flex-1 min-h-0 pt-2 pr-1">
              {sites.length === 0 ? (
                <div className="text-center py-4 text-[11px] text-slate-500 font-medium">
                  No farm locations recorded yet. Upload a demand document to discover.
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {sites.map(site => {
                    const sitePRCount = prs.filter(p => p.siteName.toLowerCase().includes(site.region.toLowerCase()) || p.siteName === site.name).length;
                    return (
                      <div
                        key={site.id}
                        onClick={() => {
                          setSearchQuery(site.name);
                          setActiveTab('ledger');
                        }}
                        className="p-2 rounded-lg bg-slate-50 border border-slate-200 hover:border-blue-400 hover:bg-blue-50/50 transition-all cursor-pointer group flex items-center justify-between shadow-2xs"
                      >
                        <div className="truncate pr-1">
                          <h4 className="text-[11px] font-bold text-slate-900 truncate group-hover:text-blue-900 transition-colors">
                            {site.name}
                          </h4>
                        </div>
                        <span className="text-[10px] font-extrabold text-amber-950 px-1.5 py-0.5 rounded bg-amber-100 border border-amber-300 shrink-0">
                          {sitePRCount} PRs
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
