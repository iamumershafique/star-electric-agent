export type BrandCategory = 
  | 'Pakistan Cables'
  | 'Amer Cables'
  | 'Schneider Electric'
  | 'Terasaki'
  | 'Philips / Pak Lighting'
  | 'Conduit & Accessories'
  | 'Switches & Sockets'
  | 'General Electrical';

export type ItemStatus = 'Pending' | 'Partially Fulfilled' | 'Completed';
export type PRStatus = 'Pending' | 'In-Progress' | 'Fulfilled';
export type NavigationTab = 'dashboard' | 'ledger' | 'deliveries' | 'brands' | 'search';

export interface LineItem {
  id: string;
  name: string;
  brand: BrandCategory;
  requestedQty: number;
  fulfilledQty: number;
  unit: string;
  unitPricePKR: number;
  status: ItemStatus;
  specifications?: string;
}

export type TransportType = 'Adda / Goods Transport' | 'Pickup / Driver';

export interface FulfillmentLog {
  id: string;
  dcNumber: string;
  invoiceNumber: string; // Strictly equals dcNumber
  prNumber: string;
  itemId: string;
  itemName: string;
  quantityShipped: number;
  date: string;
  transportType?: TransportType;
  addaName?: string;
  biltyNumber?: string;
  freightCharges?: number;
  isFreightFree?: boolean;
  driverName?: string;
  vehicleNo?: string;
  deliveredBy?: string;
  notes?: string;
}

export interface PRRecord {
  id: string;
  prNumber: string;
  date: string;
  siteName: string;
  status: PRStatus;
  items: LineItem[];
  fulfillmentLogs: FulfillmentLog[];
  documentImage?: string;
  createdTimestamp: number;
  notes?: string;
  contactPerson?: string;
}

export interface DCRecord {
  id: string;
  dcNumber: string;
  invoiceNumber: string; // Unified: matches dcNumber
  prNumber: string;
  prId: string;
  date: string;
  siteName: string;
  itemsShipped: {
    itemId: string;
    itemName: string;
    brand: string;
    quantity: number;
    unit: string;
  }[];
  documentImage?: string;
  createdTimestamp: number;
  transportType?: TransportType;
  addaName?: string;
  biltyNumber?: string;
  freightCharges?: number;
  isFreightFree?: boolean;
  driverName?: string;
  vehicleNumber?: string;
  remarks?: string;
}

export interface SiteLocation {
  id: string;
  name: string;
  region: string;
  code: string;
}

export interface GeminiExtractionResult {
  prNumber: string; // Set to "NO PR" if no PR number exists on document
  date: string;
  siteName: string;
  lineItems: {
    name: string;
    brand: BrandCategory;
    quantity: number;
    unit: string;
    estimatedPrice?: number;
    specifications?: string;
  }[];
  confidence: number;
  rawAnalysis?: string;
}

export interface GeminiMultiPRBatchResult {
  requisitions: GeminiExtractionResult[];
  rawAnalysis?: string;
}

export interface GeminiDCExtractionResult {
  dcNumber: string;
  invoiceNumber: string;
  prNumber: string; // Auto-matched PR Number if detected
  date: string;
  siteName: string;
  driverName?: string;
  vehicleNumber?: string;
  shippedItems: {
    itemName: string;
    brand?: string;
    quantityShipped: number;
    unit: string;
  }[];
  confidence: number;
  rawAnalysis?: string;
}
