import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import type { PRRecord, DCRecord, GeminiExtractionResult, SiteLocation, LineItem, NavigationTab } from '../types';
import { 
  getPRs, 
  getDCs, 
  savePR, 
  deletePR as deletePRFromStorage, 
  deleteDC as deleteDCFromStorage,
  saveDCAndFulfillPR, 
  checkDuplicatePR,
  getGeminiApiKey,
  saveGeminiApiKey,
  masterResetWithPassword,
  resetToSeedData
} from '../lib/storage';

interface AppContextType {
  prs: PRRecord[];
  dcs: DCRecord[];
  sites: SiteLocation[];
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;

  // Search & Filters
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedStatusFilter: string;
  setSelectedStatusFilter: (status: string) => void;
  selectedSiteFilter: string;
  setSelectedSiteFilter: (site: string) => void;
  selectedBrandFilter: string;
  setSelectedBrandFilter: (brand: string) => void;

  // Modals & Triggers
  isPRUploadOpen: boolean;
  setIsPRUploadOpen: (open: boolean) => void;
  isPRReviewOpen: boolean;
  setIsPRReviewOpen: (open: boolean) => void;
  isDCUploadOpen: boolean;
  setIsDCUploadOpen: (open: boolean) => void;
  isDuplicateWarningOpen: boolean;
  setIsDuplicateWarningOpen: (open: boolean) => void;
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
  isPRDetailOpen: boolean;
  setIsPRDetailOpen: (open: boolean) => void;
  isMasterResetOpen: boolean;
  setIsMasterResetOpen: (open: boolean) => void;
  isQuickDispatchOpen: boolean;
  setIsQuickDispatchOpen: (open: boolean) => void;

  // Active Drafts & Selections
  selectedPR: PRRecord | null;
  setSelectedPR: (pr: PRRecord | null) => void;
  targetDC_PR: PRRecord | null;
  setTargetDC_PR: (pr: PRRecord | null) => void;
  quickDispatchTarget: { pr: PRRecord; items: LineItem[] } | null;
  setQuickDispatchTarget: (target: { pr: PRRecord; items: LineItem[] } | null) => void;
  pendingExtractedData: GeminiExtractionResult | null;
  setPendingExtractedData: (data: GeminiExtractionResult | null) => void;
  pendingExtractedDataList: GeminiExtractionResult[] | null;
  setPendingExtractedDataList: (list: GeminiExtractionResult[] | null) => void;
  pendingImage: string | null;
  setPendingImage: (img: string | null) => void;
  duplicateInfo: { isDuplicate: boolean; existingPR?: PRRecord; pendingPrNumber?: string } | null;
  setDuplicateInfo: (info: any) => void;

  // Settings
  geminiApiKey: string;
  updateGeminiApiKey: (key: string) => void;

  // Actions
  addNewPR: (pr: PRRecord) => boolean;
  updateExistingPR: (pr: PRRecord) => void;
  deletePR: (id: string) => void;
  deleteDC: (id: string) => void;
  recordDeliveryChallan: (
    dcData: Omit<DCRecord, 'id' | 'createdTimestamp'>, 
    fulfillmentMap: Record<string, number>
  ) => void;
  verifyAndCheckDuplicate: (prNumber: string) => { isDuplicate: boolean; existingPR?: PRRecord };
  performMasterReset: (password: string) => { success: boolean; error?: string };
  resetData: () => void;
  exportBackupJSON: () => void;
  importBackupJSON: (jsonStr: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [prs, setPRs] = useState<PRRecord[]>([]);
  const [dcs, setDCs] = useState<DCRecord[]>([]);
  
  // Dynamically derive sites strictly from uploaded PR records
  const sites = useMemo<SiteLocation[]>(() => {
    const uniqueNames = Array.from(new Set(prs.map(p => p.siteName).filter(Boolean)));
    return uniqueNames.map((name, index) => ({
      id: `site-${index + 1}`,
      name,
      region: name.includes('-') ? name.split('-')[1].trim() : name,
      code: `S-${String(index + 1).padStart(2, '0')}`
    }));
  }, [prs]);

  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('ALL');
  const [selectedSiteFilter, setSelectedSiteFilter] = useState('ALL');
  const [selectedBrandFilter, setSelectedBrandFilter] = useState('ALL');

  // Modals state
  const [isPRUploadOpen, setIsPRUploadOpen] = useState(false);
  const [isPRReviewOpen, setIsPRReviewOpen] = useState(false);
  const [isDCUploadOpen, setIsDCUploadOpen] = useState(false);
  const [isDuplicateWarningOpen, setIsDuplicateWarningOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPRDetailOpen, setIsPRDetailOpen] = useState(false);
  const [isMasterResetOpen, setIsMasterResetOpen] = useState(false);
  const [isQuickDispatchOpen, setIsQuickDispatchOpen] = useState(false);

  // Active selections
  const [selectedPR, setSelectedPR] = useState<PRRecord | null>(null);
  const [targetDC_PR, setTargetDC_PR] = useState<PRRecord | null>(null);
  const [quickDispatchTarget, setQuickDispatchTarget] = useState<{ pr: PRRecord; items: LineItem[] } | null>(null);
  const [pendingExtractedData, setPendingExtractedData] = useState<GeminiExtractionResult | null>(null);
  const [pendingExtractedDataList, setPendingExtractedDataList] = useState<GeminiExtractionResult[] | null>(null);
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [duplicateInfo, setDuplicateInfo] = useState<{ isDuplicate: boolean; existingPR?: PRRecord; pendingPrNumber?: string } | null>(null);

  // Gemini API Key
  const [geminiApiKey, setGeminiApiKeyState] = useState('');

  useEffect(() => {
    setPRs(getPRs());
    setDCs(getDCs());
    setGeminiApiKeyState(getGeminiApiKey());
  }, []);

  const updateGeminiApiKey = (key: string) => {
    saveGeminiApiKey(key);
    setGeminiApiKeyState(key);
  };

  const verifyAndCheckDuplicate = (prNumber: string) => {
    return checkDuplicatePR(prNumber);
  };

  const addNewPR = (newPR: PRRecord): boolean => {
    const dupCheck = checkDuplicatePR(newPR.prNumber, newPR.id);
    if (dupCheck.isDuplicate) {
      setDuplicateInfo({
        isDuplicate: true,
        existingPR: dupCheck.existingPR,
        pendingPrNumber: newPR.prNumber
      });
      setIsDuplicateWarningOpen(true);
      return false;
    }
    const updated = savePR(newPR);
    setPRs(updated);
    return true;
  };

  const updateExistingPR = (updatedPR: PRRecord) => {
    const updated = savePR(updatedPR);
    setPRs(updated);
  };

  const deletePR = (id: string) => {
    const updated = deletePRFromStorage(id);
    setPRs(updated);
    if (selectedPR?.id === id) {
      setSelectedPR(null);
      setIsPRDetailOpen(false);
    }
  };

  const deleteDC = (id: string) => {
    const { updatedPRs, updatedDCs } = deleteDCFromStorage(id);
    setPRs(updatedPRs);
    setDCs(updatedDCs);
  };

  const recordDeliveryChallan = (
    dcData: Omit<DCRecord, 'id' | 'createdTimestamp'>,
    fulfillmentMap: Record<string, number>
  ) => {
    const { updatedPRs, updatedDCs } = saveDCAndFulfillPR(dcData, fulfillmentMap);
    setPRs(updatedPRs);
    setDCs(updatedDCs);
    
    if (selectedPR && (selectedPR.id === dcData.prId || selectedPR.prNumber === dcData.prNumber)) {
      const refreshed = updatedPRs.find(p => p.id === selectedPR.id);
      if (refreshed) setSelectedPR(refreshed);
    }
  };

  const performMasterReset = (password: string) => {
    const res = masterResetWithPassword(password);
    if (res.success) {
      setPRs(res.prs);
      setDCs(res.dcs);
    }
    return { success: res.success, error: res.error };
  };

  const resetData = () => {
    const { prs: newPRs, dcs: newDCs } = resetToSeedData();
    setPRs(newPRs);
    setDCs(newDCs);
  };

  const exportBackupJSON = () => {
    const backup = {
      version: '1.0',
      timestamp: new Date().toISOString(),
      client: 'Jadeed Group',
      supplier: 'Star Electric Enterprises Saddar Rawalpindi',
      prs,
      dcs
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `StarElectric_JadeedDB_Backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const importBackupJSON = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.prs && Array.isArray(parsed.prs)) {
        setPRs(parsed.prs);
        localStorage.setItem('STAR_ELECTRIC_PRS_V2', JSON.stringify(parsed.prs));
      }
      if (parsed.dcs && Array.isArray(parsed.dcs)) {
        setDCs(parsed.dcs);
        localStorage.setItem('STAR_ELECTRIC_DCS_V2', JSON.stringify(parsed.dcs));
      }
      return true;
    } catch (e) {
      console.error('Invalid backup JSON file', e);
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        prs,
        dcs,
        sites,
        activeTab,
        setActiveTab,
        searchQuery,
        setSearchQuery,
        selectedStatusFilter,
        setSelectedStatusFilter,
        selectedSiteFilter,
        setSelectedSiteFilter,
        selectedBrandFilter,
        setSelectedBrandFilter,
        isPRUploadOpen,
        setIsPRUploadOpen,
        isPRReviewOpen,
        setIsPRReviewOpen,
        isDCUploadOpen,
        setIsDCUploadOpen,
        isDuplicateWarningOpen,
        setIsDuplicateWarningOpen,
        isSettingsOpen,
        setIsSettingsOpen,
        isPRDetailOpen,
        setIsPRDetailOpen,
        isMasterResetOpen,
        setIsMasterResetOpen,
        isQuickDispatchOpen,
        setIsQuickDispatchOpen,
        selectedPR,
        setSelectedPR,
        targetDC_PR,
        setTargetDC_PR,
        quickDispatchTarget,
        setQuickDispatchTarget,
        pendingExtractedData,
        setPendingExtractedData,
        pendingExtractedDataList,
        setPendingExtractedDataList,
        pendingImage,
        setPendingImage,
        duplicateInfo,
        setDuplicateInfo,
        geminiApiKey,
        updateGeminiApiKey,
        addNewPR,
        updateExistingPR,
        deletePR,
        deleteDC,
        recordDeliveryChallan,
        verifyAndCheckDuplicate,
        performMasterReset,
        resetData,
        exportBackupJSON,
        importBackupJSON
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
