import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  Zap, 
  FileUp, 
  Truck, 
  Settings, 
  LayoutDashboard, 
  BookOpen, 
  FileText, 
  BarChart3, 
  Building2,
  MapPin,
  Sparkles,
  RotateCcw,
  Search
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    activeTab, 
    setActiveTab, 
    setIsPRUploadOpen, 
    setIsDCUploadOpen, 
    setIsSettingsOpen,
    setIsMasterResetOpen,
    geminiApiKey,
    prs
  } = useApp();

  const pendingPRsCount = prs.filter(p => p.status === 'Pending').length;

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs w-full">
      <div className="w-full px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-amber-500 flex items-center justify-center shadow-md shadow-amber-500/20 text-slate-950 font-bold">
              <Zap className="w-6 h-6 fill-slate-950 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-extrabold tracking-tight text-slate-900 flex items-center gap-2">
                  STAR ELECTRIC ENTERPRISES
                </h1>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 font-bold flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-amber-700" /> Saddar, Rawalpindi
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span className="flex items-center gap-1 text-slate-700 font-semibold">
                  <Building2 className="w-3.5 h-3.5 text-blue-600" /> Client: <span className="text-blue-800 font-extrabold">JADEED GROUP (POULTRY DIVISION)</span>
                </span>
                <span className="text-slate-300">•</span>
                <span>Supply Chain Portal</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => setIsPRUploadOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all transform active:scale-95"
            >
              <FileUp className="w-4 h-4" />
              Scan Demand PR
              <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-amber-300 font-bold flex items-center gap-0.5">
                <Sparkles className="w-2.5 h-2.5" /> AI
              </span>
            </button>

            <button
              onClick={() => setIsDCUploadOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all transform active:scale-95"
            >
              <Truck className="w-4 h-4" />
              Scan / Record DC & Invoice
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-800 text-white font-bold">
                AI / Manual
              </span>
            </button>

            {/* Master Reset Button */}
            <button
              onClick={() => setIsMasterResetOpen(true)}
              className="px-3.5 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 font-bold text-xs border border-rose-300 flex items-center gap-1.5 transition-all"
              title="Master Reset Database (Password 2214 Required)"
            >
              <RotateCcw className="w-3.5 h-3.5 text-rose-700" />
              Master Reset
            </button>

            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 transition-colors relative"
              title="Settings & Gemini API Configuration"
            >
              <Settings className="w-4.5 h-4.5" />
              {!geminiApiKey && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-500 rounded-full animate-ping" />
              )}
            </button>
          </div>

        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 border-t border-slate-200 mt-3 pt-3 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors ${
              activeTab === 'dashboard'
                ? 'bg-amber-100 text-amber-950 border border-amber-300 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 text-amber-600" />
            Executive Dashboard
          </button>

          <button
            onClick={() => setActiveTab('search')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors ${
              activeTab === 'search'
                ? 'bg-amber-100 text-amber-950 border border-amber-300 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Search className="w-4 h-4 text-amber-700" />
            Global Search & Audit Hub
          </button>

          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors relative ${
              activeTab === 'ledger'
                ? 'bg-amber-100 text-amber-950 border border-amber-300 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <BookOpen className="w-4 h-4 text-blue-600" />
            Master Requisition Ledger
            {pendingPRsCount > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] rounded-full bg-rose-100 text-rose-900 border border-rose-300 font-extrabold">
                {pendingPRsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('deliveries')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors ${
              activeTab === 'deliveries'
                ? 'bg-amber-100 text-amber-950 border border-amber-300 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-600" />
            Delivery Challans & Invoices
          </button>

          <button
            onClick={() => setActiveTab('brands')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors ${
              activeTab === 'brands'
                ? 'bg-amber-100 text-amber-950 border border-amber-300 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-purple-600" />
            Brand Analytics
          </button>
        </div>
      </div>
    </header>
  );
};
