import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Settings, 
  X, 
  Key, 
  Database, 
  Download, 
  Upload, 
  RotateCcw, 
  Sparkles,
  CheckCircle2
} from 'lucide-react';

export const SettingsModal: React.FC = () => {
  const { 
    isSettingsOpen, 
    setIsSettingsOpen, 
    geminiApiKey, 
    updateGeminiApiKey, 
    exportBackupJSON,
    importBackupJSON,
    setIsMasterResetOpen
  } = useApp();

  const [inputKey, setInputKey] = useState(geminiApiKey);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  if (!isSettingsOpen) return null;

  const handleSaveKey = () => {
    updateGeminiApiKey(inputKey.trim());
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        const success = importBackupJSON(content);
        if (success) {
          setImportStatus('Database imported successfully!');
        } else {
          setImportStatus('Failed to import backup file. Invalid format.');
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/30 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-6 relative overflow-hidden text-slate-900">
        
        <div className="flex items-center justify-between border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-300 flex items-center justify-center text-amber-700">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-slate-900">
                Settings & Integration Config
              </h3>
              <p className="text-xs text-slate-500 font-medium">Google Gemini API & Local Storage Management</p>
            </div>
          </div>

          <button
            onClick={() => setIsSettingsOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 bg-amber-50/60 p-4 rounded-xl border border-amber-200">
          <label className="text-xs font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-700" />
            Google Gemini API Key
          </label>
          <p className="text-[11px] text-slate-600 font-medium">
            Configure your Gemini API Key for live OCR scanning of demand requisitions & Delivery Challans. (If left blank, the app uses an intelligent OCR simulator).
          </p>

          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Key className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="password"
                value={inputKey}
                onChange={(e) => setInputKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-white border border-slate-300 text-slate-900 text-xs font-mono font-bold focus:outline-none focus:border-amber-500"
              />
            </div>
            <button
              onClick={handleSaveKey}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs transition-colors shadow-2xs"
            >
              Save Key
            </button>
          </div>

          {saveSuccess && (
            <div className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> API Key saved to browser local storage!
            </div>
          )}
        </div>

        <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <label className="text-xs font-bold text-slate-900 flex items-center gap-2">
            <Database className="w-4 h-4 text-blue-600" />
            Database Backup & Portability
          </label>
          <p className="text-[11px] text-slate-600 font-medium">
            Export database JSON for VS Code / external database migration (Supabase, PostgreSQL).
          </p>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={exportBackupJSON}
              className="px-3 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" /> Export JSON
            </button>

            <label className="px-3 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs">
              <Upload className="w-3.5 h-3.5 text-blue-600" /> Import JSON
              <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
            </label>
          </div>

          {importStatus && (
            <div className="text-[11px] text-amber-800 font-bold">
              {importStatus}
            </div>
          )}
        </div>

        <div className="pt-2 border-t border-slate-200 flex justify-between items-center">
          <button
            onClick={() => {
              setIsSettingsOpen(false);
              setIsMasterResetOpen(true);
            }}
            className="text-xs text-rose-700 hover:text-rose-800 flex items-center gap-1 font-bold bg-rose-50 px-3 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-100 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Master Reset (Password 2214)
          </button>

          <button
            onClick={() => setIsSettingsOpen(false)}
            className="px-4 py-2 rounded-xl bg-slate-100 text-slate-800 text-xs font-bold hover:bg-slate-200"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
